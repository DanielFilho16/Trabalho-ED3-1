//
// Created by Henrique on 25/09/2023.
//

#ifndef UNTITLED_AUX_FUNCOES_H
#define UNTITLED_AUX_FUNCOES_H

int cria_tabela(char *arquivo);

#endif //UNTITLED_AUX_FUNCOES_H
