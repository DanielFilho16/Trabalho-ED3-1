
#include "aux_geral.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void readline(char* string){
    char c = 0;

    do{
        c = (char) getchar();

    } while(c == '\n' || c == '\r');

    int i = 0;

    do{
        string[i] = c;
        i++;
        c = getchar();
    } while(c != '\n' && c != '\r');

    string[i]  = '\0';
}

void binarioNaTela(char *nomeArquivoBinario) { /* Você não precisa entender o código dessa função. */

    /* Use essa função para comparação no run.codes. Lembre-se de ter fechado (fclose) o arquivo anteriormente.
    *  Ela vai abrir de novo para leitura e depois fechar (você não vai perder pontos por isso se usar ela). */

    unsigned long i, cs;
    unsigned char *mb;
    size_t fl;
    FILE *fs;
    if(nomeArquivoBinario == NULL || !(fs = fopen(nomeArquivoBinario, "rb"))) {
        fprintf(stderr, "ERRO AO ESCREVER O BINARIO NA TELA (função binarioNaTela): não foi possível abrir o arquivo que me passou para leitura. Ele existe e você tá passando o nome certo? Você lembrou de fechar ele com fclose depois de usar?\n");
        return;
    }
    fseek(fs, 0, SEEK_END);
    fl = ftell(fs);
    fseek(fs, 0, SEEK_SET);
    mb = (unsigned char *) malloc(fl);
    fread(mb, 1, fl, fs);

    cs = 0;
    for(i = 0; i < fl; i++) {
        cs += (unsigned long) mb[i];
    }
    printf("%lf\n", (cs / (double) 100));
    free(mb);
    fclose(fs);
}

void scan_quote_string(char *str) {

    /*
    *	Use essa função para ler um campo string delimitado entre aspas (").
    *	Chame ela na hora que for ler tal campo. Por exemplo:
    *
    *	A entrada está da seguinte forma:
    *		nomeDoCampo "MARIA DA SILVA"
    *
    *	Para ler isso para as strings já alocadas str1 e str2 do seu programa, você faz:
    *		scanf("%s", str1); // Vai salvar nomeDoCampo em str1
    *		scan_quote_string(str2); // Vai salvar MARIA DA SILVA em str2 (sem as aspas)
    *
    */

    char R;

    while((R = getchar()) != EOF && isspace(R)); // ignorar espaços, \r, \n...

    if(R == 'N' || R == 'n') { // campo NULO
        getchar(); getchar(); getchar(); // ignorar o "ULO" de NULO.
        strcpy(str, ""); // copia string vazia
    } else if(R == '\"') {
        if(scanf("%[^\"]", str) != 1) { // ler até o fechamento das aspas
            strcpy(str, "");
        }
        getchar(); // ignorar aspas fechando
    } else if(R != EOF){ // vc tá tentando ler uma string que não tá entre aspas! Fazer leitura normal %s então, pois deve ser algum inteiro ou algo assim...
        str[0] = R;
        scanf("%s", &str[1]);
    } else { // EOF
        strcpy(str, "");
    }
}

struct Registro *novoRegistro(){
    Registro *registro = (Registro *)malloc(sizeof(TAM_REGISTRO));
    if(registro == NULL){
        printf("Erro ao alocar memoria do registro");
    };

    //Malocando e inicializando TecnologaOrigem
    registro->tecnologiaOrigem.tamanho = 0;//Colocar dps que ler
    registro->tecnologiaOrigem.string = (char *)malloc((TAM_TECNOLOGIA) * sizeof(char));
    strcpy(registro->tecnologiaOrigem.string, "NULL"); //ADicionar o valor aqui

    //Malocando e inicializando TecnologiasDestino
    registro->tecnologiaDestino.tamanho = 0;// Colocar dps que ler
    registro->tecnologiaDestino.string = (char *)malloc((TAM_TECNOLOGIA) * sizeof(char));
    strcpy(registro->tecnologiaDestino.string, "NULL"); //ADicionar o valor aqui

    //Inicializando as partes estaticas do registro como valores padroes para caso faltar dados
    registro->removido = '0';
    registro->grupo = 0;
    registro->popularidade = 0;
    registro->peso = 0;

    return registro;

}
void deletaRegistro(Registro *registro){

    if(registro->tecnologiaOrigem.string!= NULL){
        free(registro->tecnologiaOrigem.string);
    }
    if(registro->tecnologiaDestino.string!= NULL){
        free(registro->tecnologiaDestino.string);
    }


    free(registro);
}

struct Cabecalho *novoCabecalho(){
    Cabecalho *cabecalho = (Cabecalho *)malloc(sizeof(TAM_CABECALHO));
    if(cabecalho == NULL){
        printf("Erro ao alocar memoria do cabecalho");
    }

    //Inicializando struct de cabecalho
    cabecalho->status = 1; //indica se o arquivo de dados esta consistente 0(setar 0 ao abrir para escrita) 1(apos escrever)
    cabecalho->proxRRN =0; //iniciado com 0
    cabecalho->nroTecnologias = 0; //quantidade, inciail eh 0, apenas diferentes
    cabecalho->nroParesTecnologias =0;

    return cabecalho;
}
void deletaCabecalho(Cabecalho *cabecalho){
    free(cabecalho);

}

struct Lista *novaLista(){
    Lista *l = (Lista *) malloc(sizeof (Lista));

    if(l == NULL){
        printf(" Erro de alocação de memoria");
        return 0;
    }

    l->inicio = NULL;
    l->qnt = 0;

}

int lerLinhaCSV(FILE *arquivoCSV, Registro *registro) {
    char linha[1024]; // Assumindo que cada linha do CSV tem menos de 1024 caracteres
    if (fgets(linha, sizeof(linha), arquivoCSV) == NULL) {
        return 0; // Fim do arquivo
    }

    // Inicializa campos opcionais com valores padrão
    registro->tecnologiaOrigem.string = NULL;
    registro->tecnologiaDestino.string = NULL;

    // Analisa os campos da linha
    char *token = strtok(linha, ",");
    registro->removido = '0';
    if (token) {
        registro->tecnologiaOrigem.tamanho = strlen(token);
        registro->tecnologiaOrigem.string = strdup(token);
    }
    token = strtok(NULL, ",");
    registro->grupo = atoi(token);


    token = strtok(NULL, ",");
    registro->popularidade = atoi(token);
    token = strtok(NULL, ",");
    if (token) {
        registro->tecnologiaDestino.tamanho = strlen(token);
        registro->tecnologiaDestino.string = strdup(token);
    }
    token = strtok(NULL, ",");
    registro->peso = atoi(token);



    return 1;
}

void registroNaLista(Registro *registro,Lista *lista){

    if(lista == NULL || registro == NULL){
        return;
    }

    No *novo = (No *) malloc(sizeof(No));
    if(novo == NULL){
        printf("Erro de alocação de memoria");
        return;
    }

    novo->reg = registro;
    novo->prox = NULL;

    lista->qnt++;

    if(lista->inicio == NULL){
            lista->inicio = novo;
    }

    else{
        No *aux = lista->inicio;

        while(aux->prox != NULL){

            aux = aux->prox;

        }

        aux->prox = novo;

    }
}
int procura_tecnologia(Lista *lista,Registro *registro){

    No *n = lista->inicio;

    while (n != NULL){

        if (strcmp(n->reg->tecnologiaOrigem.string, registro->tecnologiaOrigem.string) == 0){
            return 1;
        }

        n = n->prox;
    }
    return 0;
}
int procura_par(Lista *lista,Registro *registro){

    No *n = lista->inicio;

    while (n != NULL){

        if (strcmp(n->reg->tecnologiaOrigem.string, registro->tecnologiaOrigem.string) == 0){
            if((n->reg->tecnologiaDestino.string == NULL) || strcmp(n->reg->tecnologiaDestino.string,"\n")  == 0){
                return 0;
            }
            if((registro->tecnologiaDestino.string == NULL) || strcmp(registro->tecnologiaDestino.string,"\n")  == 0){
                return 0;
            }
            if (strcmp(n->reg->tecnologiaDestino.string, registro->tecnologiaDestino.string) == 0){
                return 0;
            }

            if(strcmp(n->reg->tecnologiaDestino.string, registro->tecnologiaOrigem.string) == 0 && strcmp(n->reg->tecnologiaOrigem.string, registro->tecnologiaDestino.string) == 0){
                return 0;
            }

            return 1;
        }

        n = n->prox;
    }

    return 0;
}

void escreverCabecalho(FILE *arquivoBinario, const Cabecalho *cabecalho) {
    fwrite(cabecalho, sizeof(Cabecalho), 1, arquivoBinario);
}
//Funcao para escrever registro variavel
// Tecnologia Origem
//    if(registro->tecnologiaOrigem.tamanho < 1){
//        strcpy(registro->tecnologiaOrigem.string, NULL);
//    } else {
//        registro->tecnologiaOrigem.string = (char *)malloc((TAM_TECNOLOGIA) * sizeof(char));
//        strcpy(registro->tecnologiaOrigem.string, "VAlor"); //ADicionar o valor aqui
//    }
//
//    //Tecnologia Destino
//    if(registro->tecnologiaDestino.tamanho < 1){
//        strcpy(registro->tecnologiaDestino.string, NULL);
//    } else {
//        registro->tecnologiaDestino.string = (char *)malloc((TAM_TECNOLOGIA) * sizeof(char));
//        strcpy(registro->tecnologiaDestino.string, "VAlor"); //ADicionar o valor aqui
//    }

int n_de_registro(FILE *arquivoCSV){
    long contador = 0;
    char flag[1];
    while(fread(flag, 1, 1, arquivoCSV)) contador++;  // conta caracter por caracter
    return contador / TAM_REGISTRO;
} //função que vai contar para definir RRN, substituir arq pela struct

void leitura_tabela(FILE *arquivoCSV, Registro *Registro){
    fread(&Registro->tecnologiaOrigem, sizeof(char), 51, arquivoCSV);
    fread(&Registro->grupo, sizeof(int), 51, arquivoCSV);
    fread(&Registro->popularidade, sizeof(int ), 81, arquivoCSV);
    fread(&Registro->tecnologiaDestino, sizeof(char), 51, arquivoCSV);
    fread(&Registro->peso, sizeof(int), 1, arquivoCSV);
}

void exibe(Registro *Registro){
    printf("nomeTecnologiaOrigem: %s\n", Registro->tecnologiaOrigem.string);
    printf("grupo: %d\n", Registro->grupo);
    printf("popularidade: %d\n", Registro->popularidade);
    printf("nomeTecnologiaDestino: %s\n", Registro->tecnologiaDestino.string);
    printf("peso: %d\n\n", Registro->peso);
}

//PARTE3
Cabecalho *bin_read_header(FILE *binfp)
{
    /*------------------------------------------
Lê todo o cabeçalho do arquivo Binário

@Params: binfp -> ponteiro do arquivo binário
@Return: ponteiro para o cabeçalho lido
------------------------------------------*/
    Cabecalho *ret = (Cabecalho *)malloc(sizeof(Cabecalho));

    if (ret == NULL)
    {
        printf("> Erro de alocação de memoria na funcao bin_read_header(). Encerrando programa...\n");
        //exit(MEM_ALLOC_ERROR);
    }

    fseek(binfp, 0, SEEK_SET);

    fread(&(ret->status), 1, sizeof(char), binfp);
    fread(&(ret->proxRRN), 1, sizeof(size_t), binfp);
    fread(&(ret->nroTecnologias), 1, sizeof(int), binfp);
    fread(&(ret->nroParesTecnologias), 1, sizeof(int), binfp);

    return ret;
}//arrumar

int simplifica(char *str)
{
    /*------------------------------------------
Função que converte os possíveis nome de campo para um valor numérico

@Params: str -> nome do campo
@Return: valor do código (0 -> nenhum campo com esse nome encontrado)
------------------------------------------*/
    if (strcmp(str, "codEstacao") == 0)
    {
        return 1;
    }
    else if (strcmp(str, "nomeEstacao") == 0)
    {
        return 2;
    }
    else if (strcmp(str, "codLinha") == 0)
    {
        return 3;
    }
    else if (strcmp(str, "nomeLinha") == 0)
    {
        return 4;
    }
    else if (strcmp(str, "codProxEstacao") == 0)
    {
        return 5;
    }
    else if (strcmp(str, "distProxEstacao") == 0)
    {
        return 6;
    }
    else if (strcmp(str, "codLinhaIntegra") == 0)
    {
        return 7;
    }
    else if (strcmp(str, "codEstacaoIntegra") == 0)
    {
        return 8;
    }

    return 0;
}

Cabecalho *teste(FILE *binario)
{
    /*------------------------------------------
Lê todo o cabeçalho do arquivo Binário

@Params: binfp -> ponteiro do arquivo binário
@Return: ponteiro para o cabeçalho lido
------------------------------------------*/
    //Cabecalho *ret = (Cabecalho *)malloc(sizeof(Cabecalho));
    Cabecalho *cabecalho = (Cabecalho *)malloc(sizeof(Cabecalho));

    if (cabecalho == NULL)
    {
        printf("> Erro de alocação de memoria na funcao bin_read_header(). Encerrando programa...\n");
        //exit(MEM_ALLOC_ERROR);
    }

    fseek(binario, 0, SEEK_SET);

    fread(&(cabecalho->status), sizeof(char),1, binario);
    fread(&(cabecalho->proxRRN),sizeof(int),1, binario);
    fread(&(cabecalho->nroTecnologias), sizeof(int), 1, binario);
    fread(&(cabecalho->nroParesTecnologias), sizeof(int), 1, binario);

    return cabecalho;
}

LIST *busca_arq_b(FILE *binfp, Buscar *busca, int n)
{
    /*------------------------------------------
Realiza a busca no arquivo binário de acordo com a combinação de filtros em fieldCode e fieldValue.
Armazena todos os registros que condizerem com os valores buscados em uma lista encadeada

@Params: binfp -> ponteiro do arquivo binário; searches -> filtros; n-> quantidade de filtros
@Return: Lista encadeada com todos os registros buscados
------------------------------------------*/
    if (binfp == NULL)
    {
        return NULL;
    }

    fseek(binfp, 17, SEEK_SET);

    LIST *results = list_create(); //Lista que armazenara os registros buscados
    Registro *aux = NULL;          //Armazena os valores do registro atual
    int acceptedReg;               //Flag que indicará se o registro é ou não
    while (!feof(binfp))
    {
        aux = bin_read_register(binfp); //Chama a função para ler o próximo registro do arquivo

        if (aux != NULL)
        {                       // bin_read_register() pode retornar null (removido logicamente)
            acceptedReg = 1; // Considera-se que o registro é válido até encontrar alguma diferença com os campos de busca
            for (int i = 0; i < n; i++)
            {
                if (!bin_verify_search(aux, busca[i]))
                { // Caso o registro não passe em algum dos filtros de busca, altera a flag
                    acceptedReg = 0;
                    break;
                }
            }

            if (acceptedReg)
            { // Se ele for um registro que corresponde a busca, entra na lista de resultados
                list_append(results, aux);
            }
        }
    }

    return results;
}

void parte_3()//função principal
{
//Recebe uma entrada de nome de arquivo e o abre(binário)
    char nome_arq[TAM_REGISTRO];//Tamanho genérico
    scanf("%s", nome_arq);
    FILE *arq = fopen(nome_arq, "rb");
    if (arq == NULL)
    {
        printf("Falha no processamento do arquivo.  Nao abriu\n");
        return;
    }

// Quantas buscas o usuário quer fazer
    int n;
    scanf("%d", &n);

//Criando uma matriz para armazenar as strings
    Buscar *busca = (Buscar *)malloc(n * sizeof(Buscar));
    leitura_busca(busca, n);

//Leitura do Cabeçalho do arquivo(status,proxRRN, nroTecnologias, nroParesTecnologias)
    Cabecalho *h = teste(arq);
    if (h->nroTecnologias <= 0)
    { // Caso o arquivo não possua registros não-removidos
        printf("Registro inexistente.\n");
        return;
    }

    LIST *resultado = busca_arq_b(arq, busca, n); // Realiza a busca no arquivo e retorna uma lista de resultados

    if (resultado->qnt == 0)
    { // Caso nenhum registro atenda aos resultados
        printf("Registro inexistente.\n");
        return;
    }
//Exibe todo o resultado da lista
    while (resultado->qnt > 0)
    {
        Registro *tmp = lista_limpa(resultado); // Pega o primeiro termo da lista

        print_final(tmp); // Imprime o registro
        limpa_registro(tmp);       // free na memoria
    }

    // Free os termos de pesquisa, lista e cabeçalho, sucessivaemnte.
    limpa_bin(busca, n);
    limpa_lista(resultado);
    free(h);

// Fecha o arquivo
    fclose(arq);
}

void limpa_lista(LIST *l)
{
    /*------------------------------------------
Desaloca tudo que estiver na lista encadeada

@Params: l -> ponteiro para a lista
@Return: nenhum
------------------------------------------*/
    No *n = l->start;
    No *ant;

    // Percorre todos os nós da lista
    while (n != NULL)
    {

        reg_delete(n->reg); // Exclui o registro do nó
        ant = n;
        n = n->prox;
        free(ant); // Exclui o nó
    }

    free(l); // Exclui a lista
}
void limpa_bin(Buscar *busca, int tam)
{
    /*------------------------------------------
 Recebe um vetor de SEARCH e desaloca tudo que pertemne a ele

 @Params: search -> vetor a ser desalocado; tam -> tamanho do vetor
 @Return: nenhum
------------------------------------------*/
    if (busca == NULL)
    {
        return;
    }

    for (int i = 0; i < tam; i++)
    {
        if (busca[i].conteudo != NULL)
        {
            free(busca[i].conteudo);
        }
    }

    free(busca);

    return;
}
void leitura_busca(Buscar *busca, int qnt) //transforma o nome em um número (indice)
{
    {
        /*------------------------------------------
    Função auxiliar para ler todos os campos de busca presentes na tela

    @Params: code -> código do nome do campo
    @Return: nenhum
    ------------------------------------------*/
        char termo_busca[TAM_REGISTRO], aux[TAM_REGISTRO]; //Armazena o nome atual do campo, para convertê-lo para um código numérico
        for (int i = 0; i < qnt; i++)
        {

            scanf("%s", termo_busca);                                //Lê o nome do campo
            busca[i].id = simplifica(termo_busca); //Converte o nome do campo em um código numérico (simplifica o algoritmo de busca)
            ler_aspas(aux);                            // Lê o valor de busca

            if (teste_str(busca[i].id))
            { // Verifica se o campo de busca é um campo de texto

                busca[i].conteudo = (char *)malloc(TAM_REGISTRO * sizeof(char)); //Aloca uma string da estrutura de busca
                strcpy(busca[i].conteudo, aux);

                //valor default para numero
                busca[i].valor =-1;
            }
            else
            { // Qualquer outro campo de dados nada mais é que um número

                if (strcmp(aux, "") == 0)
                { // Se for um campo nulo, coloca o valor de busca como -1
                    busca[i].valor = -1;
                }
                else
                { // Caso não seja nulo, apenas converte a string para inteiro
                    busca[i].valor = atoi(aux);
                }
                //valor default para string
                busca[i].conteudo = NULL;
            }
        }
        return;
    }}
void ler_aspas(char *str)
{

    /*
	*	Use essa função para ler um campo string delimitado entre aspas (").
	*	Chame ela na hora que for ler tal campo. Por exemplo:
	*
	*	A entrada está da seguinte forma:
	*		nomeDoCampo "MARIA DA SILVA"
	*
	*	Para ler isso para as strings já alocadas str1 e str2 do seu programa, você faz:
	*		scanf("%s", str1); // Vai salvar nomeDoCampo em str1
	*		scan_quote_string(str2); // Vai salvar MARIA DA SILVA em str2 (sem as aspas)
	*
	*/

    char R;

    while ((R = getchar()) != EOF && isspace(R))
        ; // ignorar espaços, \r, \n...

    if (R == 'N' || R == 'n')
    { // campo NULO
        getchar();
        getchar();
        getchar();       // ignorar o "ULO" de NULO.
        strcpy(str, ""); // copia string vazia
    }
    else if (R == '\"')
    {
        if (scanf("%[^\"]", str) != 1)
        { // ler até o fechamento das aspas
            strcpy(str, "");
        }
        getchar(); // ignorar aspas fechando
    }
    else if (R != EOF)
    { // vc tá tentando ler uma string que não tá entre aspas! Fazer leitura normal %s então, pois deve ser algum inteiro ou algo assim...
        str[0] = R;

        int i = 1;
        while ((R = getchar()) != EOF && R != '\n' && R != ' ')
        {
            str[i] = R;
            i++;
        }

        str[i] = '\0';
    }
    else
    { // EOF
        strcpy(str, "");
    }
}//mudar
void print_final(Registro * reg)
{
/*------------------------------------------
Imprime a tupla na forma requisitada para o problema

@Params: reg -> ponteiro para o registro
@Return: nenhum
------------------------------------------*/
    printf("%s ",reg->tecnologiaOrigem.string);
    printf("%d ",reg->grupo);
    printf("%d ",reg->popularidade);
    printf("%s ",reg->tecnologiaDestino.string);
    printf("%d ",reg->peso);
//    if(reg->codProxEstacao != -1){
//        printf("%d ",reg->codProxEstacao);
//    }else{
//        printf("NULO ");
//    }
//
//    if(reg->distProxEstacao != -1){
//        printf("%d ",reg->distProxEstacao);
//    }else{
//        printf("NULO ");
//    }
//
//    if(reg->codLinhaIntegracao != -1){
//        printf("%d ",reg->codLinhaIntegracao);
//    }else{
//        printf("NULO ");
//    }
//
//    if(reg->codEstIntegracao != -1){
//        printf("%d\n",reg->codEstIntegracao);
//    }else{
//        printf("NULO\n");
//    }
}
void reg_delete(Registro * reg)
{
/*------------------------------------------
Essa função desaloca um registro já criado anteriormente

@Params: ponteiro para o registro a ser desalocado
@Return: nenhum
------------------------------------------*/

    if(reg->tecnologiaDestino.string != NULL){
        free(reg->tecnologiaDestino.string);
    }

    if(reg->tecnologiaOrigem.string != NULL){
        free(reg->tecnologiaOrigem.string);
    }

    free(reg);

    return;
}
LIST *list_create()
{
    /*------------------------------------------
Aloca uma lista de registros vazias na memória. Caso não consiga, emite uma saída 2 para o programa.

@Params: nenhum
@Return: ponteiro para a lista alocada
------------------------------------------*/
    LIST *ret = (LIST *)malloc(sizeof(LIST));
    if (ret == NULL)
    {
        printf("> Erro de alocação de memoria na funcao list_create(). Encerrando programa...\n");
        //exit(MEM_ALLOC_ERROR);
    }
    ret->start = NULL;
    ret->qnt = 0;
    return ret;
}//rever
Registro *bin_read_register(FILE *binfp)
{
    /*------------------------------------------
Le próximo registro presente no arquivo binário e aloca na memória a estrutura referente ao registro

@Params: binfp -> ponteiro do arquivo binário
@Return: ponteiro para o registro lido, NULL caso esteja logicamente removido
------------------------------------------*/
    Registro *registro = novoRegistro();
    if (registro == NULL)
    {
        printf("> Erro de alocação de memoria na funcao: bin_read_register(). Encerrando programa...\n");
        //exit(MEM_ALLOC_ERROR);
    }

    // Leitura dos campos fixos
    if (fread(&(registro->removido), 1, sizeof(char), binfp))
    { // Se conseguir ler, continua a leitura
        if (registro->removido == '0')
        { // Se o registro não foi removido, lê
            fread(&(registro->grupo), 1, sizeof(int), binfp);
            fread(&(registro->popularidade), 1, sizeof(int), binfp);
            fread(&(registro->peso), 1, sizeof(int), binfp);


            // Leitura dos campos variáveis
            fread(&registro->tecnologiaOrigem.tamanho, sizeof(int), 1, binfp);
            registro->tecnologiaOrigem.string = bin_read_string(binfp);
            if (feof(binfp)) {
                return 0;
            }

            char lixo = '$';
            while (!feof(binfp) && lixo == '$') {
                fread(&lixo, 1, sizeof(char), binfp);
            }

            if (!feof(binfp)) {
                fseek(binfp, -1, 1);
            }
            fread(&registro->tecnologiaDestino.tamanho, sizeof(int), 1, binfp);
            registro->tecnologiaDestino.string = bin_read_string(binfp);


//            fread(&registro->tecnologiaOrigem.tamanho, sizeof(int), 1, binfp);
//            fread(registro->tecnologiaOrigem.string, sizeof(char), registro->tecnologiaOrigem.tamanho, binfp);
//            fread(&registro->tecnologiaDestino.tamanho, sizeof(int), 1, binfp);
//            fread(registro->tecnologiaDestino.string, sizeof(char), registro->tecnologiaDestino.tamanho, binfp);





            bin_set_next_regs(binfp); // Lê e ignora o lixo no final do registro
            return registro;
        }
        else
        { // Se não for, posiciona o ponteiro no próximo registro
//            fread(&(ret->tamanhoRegistro), 1, sizeof(int), binfp);
//            fseek(binfp, ret->tamanhoRegistro, SEEK_CUR);
//            reg_delete(ret); // remove o espaco alocado caso esteja removido logicamente
            printf("parou aqui 776 VAI TOMA NO CUUUUUUUUUU");

            return NULL;
        }
    }
    reg_delete(registro); // remove o espaco alocado caso nao consiga ler

    return NULL;
}
void bin_set_next_regs(FILE *binfp)
{
    /*------------------------------------------
Pula todo o lixo de memória presente no final do registro

 @Params: binfp-> ponteiro para o arquivo
 @Return: Tamanho do registro compatível. Se não encontrar nenhum, retorna -1.
------------------------------------------*/
    if (feof(binfp))
    { //Não tem o que ler
        return;
    }

    char trash = LIXO;
    while (!feof(binfp) && trash == LIXO)
    { // Lê o arquivo enquanto for lixo
        fread(&trash, 1, sizeof(char), binfp);
    }

    if (!feof(binfp))
    {
        fseek(binfp, -1, SEEK_CUR); // Se chegou aqui, começou a ler o próximo registro, ou seja, precisa voltar 1 byte para ser posicionado corretamente
    }

    return;
}
Registro * reg_create() {
/*------------------------------------------
Essa função aloca uma nova estrutura de registro e retorna um ponteiro para ela.
Caso a alocação dê errado, envia a saída 2 e encerra o programa.

@Params: nenhum
@Return: ponteiro para o novo registro alocado
------------------------------------------*/
    Registro *ret = (Registro *) malloc(sizeof(Registro));
    if (ret == NULL) {
        printf("Erro de alocacao de memoria na funcao reg_create. Encerrando o programa..\n");
        exit(2);
    }
    ret->removido = '0';
    //ret->proxLista = -1;


    return ret;
}
char *bin_read_string(FILE *binfp)
{
    /*------------------------------------------
 Lê o próximo campo do registro em forma de string.
 Lê todos os caracteres em uma string auxiliar até encontrar "|"
 Contabiliza os caracteres lidos e gera uma string dinamicamente alocada e retorna o ponteiro para ela.

 [LEMBRETE: DAR FREE NA VARIÁVEL QUE RECEBE O RETORNO DA FUNÇÃO]

 @Params: binfp -> ponteiro de acesso ao arquivo CSV
 @Return: ponteiro para a string gerada
------------------------------------------*/

    char tmp[TAM_REGISTRO];
    char c;

    int size = 0;

    fread(&c, 1, sizeof(char), binfp);

    while (c != '$')
    {
        tmp[size] = c;
        size++;

        fread(&c, 1, sizeof(char), binfp);
    }

    tmp[size] = '\0';

    if (size > 0)
    {
        char *ret = (char *)malloc((size + 1 ) * sizeof(char));

        if (ret == NULL)
        {
            printf("> Erro de alocação de memoria na função bin_read_string(). Encerrando programa...\n");
            exit(2);
        }
        strcpy(ret, tmp);

        return ret;
    }

    return NULL;
}
int bin_verify_search(Registro *reg, Buscar s)
{
    /*------------------------------------------
 Recebe um registro e um filtro de busca para verificar se o registro atende

 @Params: reg -> registro a ser verificado; s -> seletor de busca
 @Return: REMOVIDO -> o registro coincide com o valor de busca; NAO_REMOVIDO -> o registro é fora do escolpo de busca
------------------------------------------*/
    switch (s.id)
    {       // Switch nos códigos dos campos de busca
        case 1: // CodEstacao
            return (reg->grupo == s.valor) ? REMOVIDO : NAO_REMOVIDO;
        case 2: // nomeEstacao
            return (strcmp(s.conteudo, reg->tecnologiaDestino.string) == 0) ? REMOVIDO : NAO_REMOVIDO;
        case 3: // codLinha
            return (reg->popularidade == s.valor) ? REMOVIDO : NAO_REMOVIDO;
        case 4: // nomeLinha
            return (strcmp(s.conteudo, reg->tecnologiaOrigem.string) == 0) ? REMOVIDO : NAO_REMOVIDO;
        case 5: // codProxEstacao
            return (reg->peso == s.valor) ? REMOVIDO : NAO_REMOVIDO;
//        case 6: // distProxEstacao
//            return (reg->distProxEstacao == s.valor) ? REMOVIDO : NAO_REMOVIDO;
//        case 7: // codLinhaIntegracao
//            return (reg->codLinhaIntegracao == s.valor) ? REMOVIDO : NAO_REMOVIDO;
//        case 8: // codEstIntegracao
//            return (reg->codEstIntegracao == s.valor) ? REMOVIDO : NAO_REMOVIDO;
        default: // valor inválido no campo de busca
            return NAO_REMOVIDO;
    }
}
int list_append(LIST *l, Registro *reg)
{
    /*------------------------------------------
Cria um no com o novo registro e adiciona-o ao final da lista.
Caso não provenha memória para o nó, emite a saída 2.

@Params: l -> ponteiro para a lista; reg -> ponteiro para o registro a ser adicionado
@Return: 0 -> erro ao adicionar; 1-> adicionado com sucesso
------------------------------------------*/
    if (l == NULL || reg == NULL)
    {
        return 0;
    }

    // Cria o novo nó
    No *new = (No *)malloc(sizeof(No));
    if (new == NULL)
    {
        printf("> Erro de alocação de memoria na funcao: list_append(). Encerrando programa...\n");
        exit(2);
    }
    new->reg = reg;
    new->prox = NULL;

    l->qnt++;

    // Caso seja o primeiro nó, adiciona ele no inicio da fila e encerra a execução
    if (l->start == NULL)
    {
        l->start = new;
        return 1;
    }

    // Caso seja qualquer outro, procura o último nó da fila e adiciona-o
    No *last = l->start;
    while (last->prox != NULL)
    {
        last = last->prox;
    }

    last->prox = new;
    return 1;
}
Registro *lista_limpa(LIST *l)
{
    /*------------------------------------------
Remove o primeiro elemento da lista e retorna o registro que ele armazena

@Params: l -> ponteiro para a lista; name -> ponteiro para a string a ser comparada
@Return: registro do antigo primeiro elemento
------------------------------------------*/
    if (l == NULL || l->start == NULL)
    { // caso a lista não esteja alocada ou esteja vazia, retorna NULL
        return NULL;
    }
    No *node = l->start; //Recebe o primeiro elemento

    Registro *ret = node->reg; //Recebe o registro do primeiro elemento
    l->start = node->prox;     //Remove o primeiro elemento da lista, tirando o ponteiro para ele
    l->qnt--;

    node->reg = NULL; //Coloca o ponteiro do "reg" do ex-primeiro elemento para NULL, para não ter problemas com o registro de retorno na hora do free

    free(node); //Desaloca o ex-primeiro elemento da memória

    //Retorna o registro
    return ret;
}
void limpa_registro(Registro * reg)
{
/*------------------------------------------
Essa função desaloca um registro já criado anteriormente

@Params: ponteiro para o registro a ser desalocado
@Return: nenhum
------------------------------------------*/

    if(reg->tecnologiaDestino.string != NULL){
        free(reg->tecnologiaDestino.string);
    }

    if(reg->tecnologiaOrigem.string != NULL){
        free(reg->tecnologiaOrigem.string);
    }

    free(reg);

    return;
}
int teste_str(int code)
{
    /*------------------------------------------
Função que recebe o código de um campo e retorna se é um campo de string ou não

@Params: code -> código do nome do campo
@Return: TRUE -> é um campo de string (nomeEstação ou nomeLinha); FALSE-> não é
------------------------------------------*/
    if (code == 2 || code == 4)
    {
            return REMOVIDO;
    }

    return NAO_REMOVIDO;
}

//int main()
//{
//    parte_3();
//}


