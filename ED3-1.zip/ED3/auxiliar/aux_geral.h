#ifndef UNTITLED_AUX_GERAL_H
#define UNTITLED_AUX_GERAL_H
#define TAM_REGISTRO 76
#define TAM_REGISTRO_FIXO 21
#define TAM_TECNOLOGIA 20
#define TAM_CABECALHO 13
#define LIXO '$'
#define REMOVIDO '1'
#define NAO_REMOVIDO '0'
#include <stdio.h>
/*------------------------------------DECLARAÇÃO DE STRUCTS--------------------------------------------------*/
typedef struct Cabecalho{
    char status; //indica se o arquivo de dados esta consistente 0(setar 0 ao abrir para escrita) 1(apos escrever)
    int proxRRN; //iniciado com 0
    int nroTecnologias; //quantidade, inciail eh 0, apenas diferentes
    int nroParesTecnologias; //quantidade, inicial eh 0, apenas diferentes
} Cabecalho;
typedef struct {
    int tamanho;
    char* string;
} StringVariavel;
typedef struct Registro{
    char removido;
    int grupo;
    int popularidade;
    int peso;
    StringVariavel tecnologiaOrigem;
    StringVariavel tecnologiaDestino;
} Registro;
        //Nó e Lista dão caracteristicas e manipulação da lista
typedef struct No{
    Registro * reg;
    struct No * prox;
}No;
typedef struct Lista{
    No * inicio;
    int qnt;
}Lista;
/* Características para busca (função 3) */
typedef struct procurar{
    int id;          //Código numérico do campo escolhido (vide auxiliar.c -> aux_string_to_code())
    int valor;           //Caso o campo seja um valor numérico, o valor de busca estará aqui
    char * conteudo;     //Caso seja um campo de string, este estará aqui
}Buscar;
/* Estrutura da lista MUDAR NOME */
typedef struct{
    No * start; //seta um ponteiro para a struct No se referindo ao inicio
    int qnt;
}LIST;

/*-----------------------------Instância uma nova struct e retorna o ponteiro -------------------------------*/

struct Registro *novoRegistro();
struct Cabecalho *novoCabecalho();
struct Lista *novaLista();


/*------------------------------------Manipulação --------------------------------------------------*/

int lerLinhaCSV(FILE *arquivoCSV, Registro *registro);
void escreverCabecalho(FILE *arquivoBinario, const Cabecalho *cabecalho);
void registroNaLista(Registro *registro,Lista *lista);
int procura_tecnologia(Lista *lista,Registro *registro);
int procura_par(Lista *lista,Registro *registro);
void leitura_busca(Buscar *busca, int qnt);
void ler_aspas(char *str);
int teste_str(int code);                    //Retorna TRUE se o codigo refere-se a uma string

/*------------------------------------Funções de Limpeza --------------------------------------------------*/
void deletaRegistro(Registro *registro);
void deletaCabecalho(Cabecalho *cabecalho);
void limpa_lista(LIST *l);
void limpa_registro(Registro * reg);//Remocao
void limpa_bin(Buscar *busca, int tam);
void reg_delete(Registro * reg);
int bin_remove(FILE * binfp,Cabecalho * h,Buscar * busca, int n);                                           //Direcionamento da busca com o objetivo de remocao
int list_remove_equivalent(LIST *l,Registro * reg);     //Remocao de um valor equivalente da lista (para manutencao do header)

/*------------------------------------Funções de Leitura --------------------------------------------------*/

void readline(char* string);
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);
int n_de_registro(FILE *arquivoCSV); //Define o número do RRN
void leitura_tabela(FILE *arquivoCSV, Registro *Registro); //Faz a leitura de dados da struct
void exibe(Registro *Registro); //Exibe os dados organizadamente na tela



void print_final(Registro * reg);
LIST * list_create();                                   //Criacao da lista
Registro * bin_read_register(FILE * binfp);
void bin_set_next_regs(FILE *binfp);
Registro * reg_create();
char *bin_read_string(FILE *binfp);
int bin_verify_search(Registro *reg, Buscar s);

//Pesquisas realizadas no arquivo binario, para insercao e atualizacao de registros MUDAR VARIAVEIS
LIST * busca_arq_b(FILE *binfp, Buscar * busca, int n);                    //Busca no arquivo binario de acordo com uma especificacao
int bin_update(FILE *binfp,Cabecalho *h,Buscar *bx, int x, Buscar *by, int y,Lista * Regs);

//Insercao e remocao
int list_append(LIST * l,Registro * reg);               //Insercao no final da lista
Registro * lista_limpa(LIST * l);                    //Retorna primeiro valor da lista logo apos remove-lo


#endif //UNTITLED_AUX_GERAL_H
