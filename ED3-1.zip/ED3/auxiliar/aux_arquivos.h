//
// Created by Henrique on 25/09/2023.
//

#ifndef UNTITLED_AUX_ARQUIVOS_H
#define UNTITLED_AUX_ARQUIVOS_H
#include <stdio.h>

FILE* abre_arquivo(char* filename, char *modo);
void fecha_arquivo(FILE *arquivo);

#endif //UNTITLED_AUX_ARQUIVOS_H
